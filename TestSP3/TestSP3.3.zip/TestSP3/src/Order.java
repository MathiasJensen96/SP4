import java.awt.image.AreaAveragingScaleFilter;
import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

public class Order {
    static Scanner input = new Scanner(System.in);
    static char t;
    static int time;
    static int i = 1;
    static int j = 0;
    static ArrayList<String> orders = new ArrayList<>();
    static int orderID;
    static String testNewString;
    static private BufferedWriter writer;
    static private BufferedReader reader;
    private static ArrayList tempList = new ArrayList();
    private static File tempFile = new File("orderList.txt");

    public static void addOrder() {

        orders.add(Main.mariosSystem.step2.get(j));
        j = j + 1;
    }

    public static void selectPizza() {

        boolean finished = false;
        while (!finished) {
            String choice = input.nextLine();
            switch (choice) {
                case "1":
                    i = 1;
                    switchOptions();
                    break;
                case "2":
                     i = 2;
                    switchOptions();
                    break;
                case "3":
                    i = 3;
                    switchOptions();
                    break;
                case "4":
                    i = 4;
                    switchOptions();
                    break;
                case "5":
                    i = 5;
                    switchOptions();
                    break;
                case "6":
                    i = 6;
                    switchOptions();
                    break;
                case "7":
                    i = 7;
                    switchOptions();
                    break;
                case "8":
                    i = 8;
                    switchOptions();
                    break;
                case "9":
                    i = 9;
                    switchOptions();
                    break;
                case "10":
                    i = 10;
                    switchOptions();
                    break;
                case "11":
                    i = 11;
                    switchOptions();
                    break;
                case "12":
                    i = 12;
                    switchOptions();
                    break;
                case "13":
                    i = 13;
                    switchOptions();
                    break;
                case "14":
                    i = 14;
                    switchOptions();
                    break;
            }
        }
    }

    public static void removeOrder() {
        ArrayList<String> content = new ArrayList<>();

        BufferedReader reader = null;
        System.out.println("Enter OrderID:");

        try {
            Scanner scan2 = new Scanner("orderList.txt");
            Scanner scan = new Scanner(System.in);
            reader = new BufferedReader(new FileReader("orderList.txt"));

            String curLine;
            String temp = String.format("%05d",scan.nextInt());

            while((curLine = reader.readLine()) !=null) {
                //System.out.println(curLine); - virker
                if (!curLine.contains(temp)) {
                    System.out.println(curLine);
                    content.add(curLine);
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        updateFileContent(content);
        Statistik.sortOrder();
    }

    private static void updateFileContent(ArrayList<String> content) {
        try {
            writer = new BufferedWriter(new FileWriter("orderList.txt"));
            for (String s: content) {
                writer.write(s);
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void addPizza() {

        Main.mariosSystem.step2.add(Main.menu.temps.get(i));
        System.out.println("The following pizza has been added to the order:");
        System.out.println(Main.mariosSystem.step2.toString());
        System.out.println("Do u want more? (Y/N)");
    }

    public static void addAnotherPizza() {
        System.out.println(Main.menu);
        System.out.println("What's next?");
    }

    public static void pickUp () {

        System.out.println("When should the order be rdy?" + "\n Type: (F/M/S)");
        System.out.println("Fast = 15 min");
        System.out.println("Medium = 30 min");
        System.out.println("Slow = 60 min");
        t = input.nextLine().charAt(0);
        if (t == 'F' || t == 'f') {
            time = 15;
            System.out.println("You choose: " + time + "min");
        } else if (t == 'M' || t == 'm') {
            time = 30;
            System.out.println("You choose: " + time + "min");
        } else if (t == 'S' || t == 's') {
            time = 60;
            System.out.println("You choose: " + time + "min");
        }
        setJ(0);
    }

    public static void setJ(int j) {
        Order.j = j;
    }

    public static void switchOptions() {
        addPizza();
        addOrder();
        Main.buyMore = input.nextLine().charAt(0);
        if (Main.buyMore == 'Y' || Main.buyMore == 'y') {
            addAnotherPizza();
        } else {
            pickUp();
            Statistik.addToOrder();
            System.out.println("You need to pay:");
            Payment.getTotalPrice();
            Statistik.addToFile();
            Main.options();
        }
    }
    public static void orderIDString() {
        orderID++;
        String orderIDNewString = String.format("%05d", orderID);
        testNewString = orderIDNewString;
    }
}