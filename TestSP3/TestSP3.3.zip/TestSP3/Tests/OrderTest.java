import org.junit.Assert;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import static org.junit.Assert.*;

public class OrderTest {
    @Test
    public void OrderTest_addOrder_verifyNewOrder() {
        Main.mariosSystem = new MariosSystem();
        try {
            Main.menu = new Menu();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        //Main.mariosSystem.step2 = new ArrayList<>();
        Assert.assertEquals(0, Main.mariosSystem.step2.size());
        Main.mariosSystem.step2.add(Main.menu.temps.get(3));
        Order.addOrder();
        Assert.assertEquals(1, Main.mariosSystem.step2.size());
    }
}